import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-params-editor',
  templateUrl: './params-editor.component.html',
  styleUrls: ['./params-editor.component.css']
})
export class ParamsEditorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
