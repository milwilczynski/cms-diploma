export interface Site {
  id: number,
  roleId: number,
  name: string,
  url: string
}
