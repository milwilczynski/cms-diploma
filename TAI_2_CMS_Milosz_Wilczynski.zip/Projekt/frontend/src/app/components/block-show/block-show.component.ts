import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-block-show',
  templateUrl: './block-show.component.html',
  styleUrls: ['./block-show.component.css']
})
export class BlockShowComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
