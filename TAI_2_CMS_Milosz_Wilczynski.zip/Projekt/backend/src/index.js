require("@babel/register");
require("dotenv").config();
require("./server");
