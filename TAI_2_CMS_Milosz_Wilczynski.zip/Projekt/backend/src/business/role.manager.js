function create(context) {
  return {};
}

export default {
  create,
};
