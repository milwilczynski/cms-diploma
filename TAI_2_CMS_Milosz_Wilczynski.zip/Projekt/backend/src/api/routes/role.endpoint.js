import business from '../../business/business.container';
import applicationException from '../../exceptions/applicationException';

const roleEndpoint = (router) => {};

export default roleEndpoint;
